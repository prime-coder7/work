<?php
// Redirect to the admin dashboard
header("Location: admin_pannel/dashboard.php");
exit();
?>
